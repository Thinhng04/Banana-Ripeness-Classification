import os
import json
import joblib
import cv2
from preprocessing.feature_extraction import extract_features, resize_with_pad_bgr

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def predict_image(image_path, feature_name="hsv_lbp"):
    # Đọc thông tin cấu hình
    with open(os.path.join(BASE_DIR, "preprocessing", "config.json"), encoding="utf-8") as f:
        config = json.load(f)

    if feature_name not in config["models"]:
        raise ValueError("Chọn hsv, lbp hoặc hsv_lbp")

    image = cv2.imread(image_path)  # BGR giống lúc train
    if image is None:
        raise ValueError("Không đọc được ảnh: " + str(image_path))

    image, valid_mask = resize_with_pad_bgr(image, tuple(config["image_size"]))
    features = extract_features(image, feature_name, valid_mask).reshape(1, -1)
    model_path = os.path.join(BASE_DIR, "models", config["models"][feature_name])
    model = joblib.load(model_path)
    label_id = int(model.predict(features)[0])
    label = config["label_map"][str(label_id)]
    return label_id, label
