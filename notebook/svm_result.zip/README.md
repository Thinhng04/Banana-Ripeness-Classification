# SVM dự đoán độ chín chuối

Chọn feature: hsv, lbp, hsv_lbp.

Cài: pip install -r requirements.txt

Ví dụ: from predict import predict_image
label_id, label = predict_image('banana.jpg', 'hsv_lbp')
print(label_id, label)
Chạy Python trong thư mục giải nén. Không có confidence.
