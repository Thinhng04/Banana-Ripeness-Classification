import cv2
import numpy as np
from skimage.feature import local_binary_pattern

def _valid_roi(image, valid_mask=None):
    if valid_mask is None: return image
    ys, xs = np.where(valid_mask > 0)
    if not len(xs) or not len(ys): raise ValueError("Mask ảnh hợp lệ rỗng")
    return image[ys.min():ys.max()+1, xs.min():xs.max()+1]

def resize_with_pad_bgr(image, img_size=(128, 128)):
    target_h, target_w = img_size
    height, width = image.shape[:2]
    scale = min(target_w / width, target_h / height)
    resized_w = max(1, min(target_w, int(round(width * scale))))
    resized_h = max(1, min(target_h, int(round(height * scale))))
    resized = cv2.resize(image, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR)
    left, top = (target_w-resized_w)//2, (target_h-resized_h)//2
    right, bottom = target_w-resized_w-left, target_h-resized_h-top
    padded = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(0,0,0))
    mask = np.zeros((target_h,target_w), dtype=np.uint8)
    mask[top:top+resized_h, left:left+resized_w] = 255
    return padded, mask

def extract_hsv(image, valid_mask=None, h_bins=16, s_bins=8):
    hsv=cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hist=cv2.calcHist([hsv],[0,1],valid_mask,[h_bins,s_bins],[0,180,0,256])
    return cv2.normalize(hist,hist).flatten().astype(np.float32)

def extract_lbp(image, valid_mask=None, P=8, R=1):
    roi=_valid_roi(image,valid_mask)
    gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
    lbp=local_binary_pattern(gray,P=P,R=R,method="uniform")
    n_bins=P+2
    hist,_=np.histogram(lbp.ravel(),bins=n_bins,range=(0,n_bins),density=True)
    return hist.astype(np.float32)

def extract_features(image, feature_name, valid_mask=None):
    if feature_name=="hsv": return extract_hsv(image,valid_mask)
    if feature_name=="lbp": return extract_lbp(image,valid_mask)
    if feature_name=="hsv_lbp": return np.hstack([extract_hsv(image,valid_mask),extract_lbp(image,valid_mask)])
    raise ValueError("Bộ đặc trưng không hợp lệ: "+str(feature_name))
