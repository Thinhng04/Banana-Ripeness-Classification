Banana MobileNetV2 — use the group manifest_used.csv exactly.
The best checkpoint is selected by validation F1-Macro (NOT test).
See manifest_used.csv, run_metadata.json, mobilenet_comparison.csv, reports/, figures/, checkpoints/.
